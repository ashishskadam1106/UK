﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CS_FeeGenerationType
/// </summary>
public class CS_FeeGenerationType
{
    public int FeeGenerationTypeId { get; set; }
    public string FeeGenerationType { get; set; }

}