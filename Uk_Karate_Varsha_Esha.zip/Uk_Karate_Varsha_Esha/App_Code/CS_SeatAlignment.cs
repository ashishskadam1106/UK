﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CS_SeatAlignment
/// </summary>
public class CS_SeatAlignment
{
	
                    public int Index { get; set; }
		            public string StudentName{get;set;}
                    public string MembershipNumber { get; set; }
                    public string Dojo { get; set; }
                    public string SeatingOrderNumber { get; set; }
                    public string UpdatedSeatingOrderNumber { get; set; }

    
}