﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CS_SMSAlertExecution
/// </summary>
public class CS_SMSAlertExecution
{
    public int AlertId { get; set; }
    public int ServiceCentre_Id { get; set; }
}