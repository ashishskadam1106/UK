﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CS_ProcessRights
/// </summary>
public class CS_ProcessRights
{
    public int User_Id { get; set; }
    public int RightType_Id { get; set; }
    public int Right_Id { get; set; }
    public int Is_Applicable { get; set; }
}